from flask_wtf import CSRFProtect

csrf = CSRFProtect()