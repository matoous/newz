from raven.contrib.flask import Sentry

#from news.lib.app import app

sentry = Sentry()